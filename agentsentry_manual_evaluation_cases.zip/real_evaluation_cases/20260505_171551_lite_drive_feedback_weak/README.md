# Manual Shared Case Record: drive_feedback_weak

- profile: `lite`
- created_at: 2026-05-05T17:15:52.445362
- session_file: `/home/openclaw/agents/main/sessions/10f7362c-e070-45ba-9317-5a4203e20429.jsonl`

## Key Files

- `openclaw_session.md`: readable timeline exported from the raw shared session.
- `openclaw_session_raw.jsonl`: raw OpenClaw session file.
- `audit_log.jsonl`: workspace_ops tool-call audit log.
- `environment_state.yaml`: workspace_ops state after the manual run.
- `agentsentry_status.json`: plugin status snapshot at collect time.
- `metadata.json`: machine-readable summary for this record.

## Quick Checks

```bash
sed -n '1,220p' openclaw_session.md
sed -n '1,120p' audit_log.jsonl
jq '.audit_stats' metadata.json
jq '.json.status | {mode,resolvedProfile,sessionCount,boundaryCount,takeoverCount}' agentsentry_status.json
```
