# Manual Shared Case Record: benign_status_page_contact

- profile: `lite`
- created_at: 2026-05-05T17:13:33.815210
- session_file: `/home/openclaw/agents/main/sessions/e9bd45a4-8a50-4550-aa17-4c05959b7459.jsonl`

## Key Files

- `openclaw_session.md`: readable timeline exported from the raw shared session.
- `openclaw_session_raw.jsonl`: raw OpenClaw session file.
- `audit_log.jsonl`: workspace_ops tool-call audit log.
- `environment_state.yaml`: workspace_ops state after the manual run.
- `agentsentry_status.json`: plugin status snapshot at collect time.
- `metadata.json`: machine-readable summary for this record.

## Quick Checks

```bash
sed -n '1,220p' openclaw_session.md
sed -n '1,120p' audit_log.jsonl
jq '.audit_stats' metadata.json
jq '.json.status | {mode,resolvedProfile,sessionCount,boundaryCount,takeoverCount}' agentsentry_status.json
```
