# Manual Shared Case Record: benign_status_page_contact

- profile: `no_defense`
- created_at: 2026-05-05T16:43:55.094836
- session_file: `/home/openclaw/agents/main/sessions/290637d4-f98e-4620-b4d5-c01256a4e5df.jsonl`

## Key Files

- `openclaw_session.md`: readable timeline exported from the raw shared session.
- `openclaw_session_raw.jsonl`: raw OpenClaw session file.
- `audit_log.jsonl`: workspace_ops tool-call audit log.
- `environment_state.yaml`: workspace_ops state after the manual run.
- `agentsentry_status.json`: plugin status snapshot at collect time.
- `metadata.json`: machine-readable summary for this record.

## Quick Checks

```bash
sed -n '1,220p' openclaw_session.md
sed -n '1,120p' audit_log.jsonl
jq '.audit_stats' metadata.json
jq '.json.status | {mode,resolvedProfile,sessionCount,boundaryCount,takeoverCount}' agentsentry_status.json
```
