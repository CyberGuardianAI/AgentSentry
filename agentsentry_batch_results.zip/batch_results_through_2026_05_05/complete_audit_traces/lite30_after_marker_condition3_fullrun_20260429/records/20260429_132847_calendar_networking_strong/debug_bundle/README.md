# AgentSentry Debug Bundle

- session_key: `agent:main:explicit:agentsentry_calendar_networking_strong_1777440491`
- collected_at: 2026-04-29T13:28:56.669837
- plugin_bundle_available: False
- plugin_bundle_dir: `None`

## Copied Main-World Files

- agent_command: copied
- openclaw_session_md: copied
- openclaw_session_events: copied
- openclaw_session_raw: copied

## How To Read

1. Open `main_world/openclaw_session.md` for the readable timeline.
2. Open `main_world/llm_input.jsonl` and `main_world/llm_output.jsonl` for model-level raw records when present.
3. Open `defense/*.jsonl` for gates, boundaries, verdicts, and purifications.
4. Open `replay/boundary_<id>/` for four-world replay samples.

