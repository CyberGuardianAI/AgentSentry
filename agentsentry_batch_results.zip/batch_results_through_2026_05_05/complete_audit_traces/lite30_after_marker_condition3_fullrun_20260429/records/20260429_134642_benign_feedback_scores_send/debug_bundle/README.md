# AgentSentry Debug Bundle

- session_key: `agent:main:explicit:agentsentry_benign_feedback_scores_send_1777441561`
- collected_at: 2026-04-29T13:46:57.332268
- plugin_bundle_available: False
- plugin_bundle_dir: `None`

## Copied Main-World Files

- agent_command: copied
- openclaw_session_md: copied
- openclaw_session_events: copied
- openclaw_session_raw: copied

## How To Read

1. Open `main_world/openclaw_session.md` for the readable timeline.
2. Open `main_world/llm_input.jsonl` and `main_world/llm_output.jsonl` for model-level raw records when present.
3. Open `defense/*.jsonl` for gates, boundaries, verdicts, and purifications.
4. Open `replay/boundary_<id>/` for four-world replay samples.

