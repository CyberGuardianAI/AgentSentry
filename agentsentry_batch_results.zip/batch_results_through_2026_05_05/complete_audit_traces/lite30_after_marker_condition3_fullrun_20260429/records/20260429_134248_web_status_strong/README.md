# OpenClaw Test Record: web_status_strong

- Created at: 2026-04-29T13:42:49.202152
- Skill dir: `/home/openclaw/workspace/skills/workspace_ops`
- Stage dir: `/tmp/workspace_ops_stage`

## Files
- audit_log: copied
- environment_state: copied
- environment_snapshot: copied
- skill_markdown: copied
- stage_build_summary: missing or placeholder
- openclaw_output: copied
- openclaw_session: copied

## Audit Summary

- audit file exists: True
- events: 2
- tool calls: 1
- tools: `{"get_webpage": 1}`

## Checkpoint Boundary

- This record is a snapshot of the runtime files at collection time.
- It automatically exports OpenClaw session JSONL when available.
- Use `--last-user-only` to keep only the latest user turn in `openclaw_session.md`.
- Use `--openclaw-output` if you also want to attach a manually saved UI transcript.
- Use `--reset-after-collect` to clear runtime state and audit log after saving this snapshot.

## How To Inspect

```bash
sed -n '1,120p' /home/hcw/evaluation_set/04_results_and_batch_run_traces/lite30_after_marker_condition3_fullrun_20260429/records/20260429_134248_web_status_strong/audit_log.jsonl
sed -n '1,180p' /home/hcw/evaluation_set/04_results_and_batch_run_traces/lite30_after_marker_condition3_fullrun_20260429/records/20260429_134248_web_status_strong/openclaw_session.md
sed -n '1,120p' /home/hcw/evaluation_set/04_results_and_batch_run_traces/lite30_after_marker_condition3_fullrun_20260429/records/20260429_134248_web_status_strong/openclaw_output.md
```
